from enum import Enum

class NiveisEnum(Enum):
    NIVEL1 = 1
    NIVEL2 = 2
    NIVEL3 = 3
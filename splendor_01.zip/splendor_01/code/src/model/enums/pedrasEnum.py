from enum import Enum

class PedrasEnum(Enum):
    ESMERALDA = "Esmeralda"
    DIAMANTE = "Diamante"
    RUBI = "Rubi"
    SAFIRA = "Safira"
    ONIX = "Onix"
    OURO = "Ouro"